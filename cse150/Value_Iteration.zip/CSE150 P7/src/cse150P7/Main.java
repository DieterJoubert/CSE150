package cse150P7;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Main {
	
	public static void main (String args[]){
		System.out.println("Enter your 4 transition matrices (actions 1-4) followed by your reward matix");
		System.out.println(">>");
		BufferedReader a1Reader = null;
		BufferedReader a2Reader = null;
		BufferedReader a3Reader = null;
		BufferedReader a4Reader = null;
		BufferedReader rewardsReader = null;
		String a,b,c,d;
		int row;
		StringTokenizer tokenizer1, tokenizer2, tokenizer3, tokenizer4;
		double[][] a1 = new double[81][81];
		double[][] a2 = new double[81][81];
		double[][] a3 = new double[81][81];
		double[][] a4 = new double[81][81];
		int[] rewards = new int[81];
		for (int i = 0; i < 81; i++){
			for(int j = 0; j < 81; j++){
				a1[i][j] = 0;
				a2[i][j] = 0;
				a3[i][j] = 0;
				a4[i][j] = 0;
			}
		}
		try{
			a1Reader = new BufferedReader(new FileReader(args[0]));
			a2Reader = new BufferedReader(new FileReader(args[1]));
			a3Reader = new BufferedReader(new FileReader(args[2]));
			a4Reader = new BufferedReader(new FileReader(args[3]));
			rewardsReader = new BufferedReader(new FileReader(args[4]));
			a = a1Reader.readLine();
			b = a2Reader.readLine();
			c = a3Reader.readLine();
			d = a4Reader.readLine();
			while(a != null){
				tokenizer1 = new StringTokenizer(a);
				tokenizer2 = new StringTokenizer(b);
				tokenizer3 = new StringTokenizer(c);
				tokenizer4 = new StringTokenizer(d);
				a1 [Integer.parseInt(tokenizer1.nextToken())-1]
				    [Integer.parseInt(tokenizer1.nextToken())-1] 
				     = Double.parseDouble(tokenizer1.nextToken());
				a2 [Integer.parseInt(tokenizer2.nextToken())-1]
					   [Integer.parseInt(tokenizer2.nextToken())-1] 
					   = Double.parseDouble(tokenizer2.nextToken());
				a3 [Integer.parseInt(tokenizer3.nextToken())-1]
					   [Integer.parseInt(tokenizer3.nextToken())-1] 
					   = Double.parseDouble(tokenizer3.nextToken());
				a4 [Integer.parseInt(tokenizer4.nextToken())-1]
					   [Integer.parseInt(tokenizer4.nextToken())-1] 
					   = Double.parseDouble(tokenizer4.nextToken());
				a = a1Reader.readLine();
				b = a2Reader.readLine();
				c = a3Reader.readLine();
				d = a4Reader.readLine();
			}
			row = -1;
		    a = rewardsReader.readLine();
			row++;
			while (a != null){
				rewards [row] = Integer.parseInt(a);
				a = rewardsReader.readLine();
				row++;
			}
		}
		catch (FileNotFoundException e){
			System.err.println("Error: File not Found!!");
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}
		catch (Exception e){		
			e.printStackTrace();
		}
		finally{
			try{
				if (a1Reader != null){
					a1Reader.close();
				}
				if (a2Reader != null){
					a2Reader.close();
				}
				if (a3Reader != null){
					a3Reader.close();
				}
				if (a4Reader != null){
					a4Reader.close();
				}
				if (rewardsReader != null){
					rewardsReader.close();
				}
			}
			catch(IOException e){
				e.printStackTrace();
			}
		}
		ValueIteration.findValues(a1, a2, a3, a4, rewards);
		//test
		/*
		for(int i = 0; i < 81; i++){
				System.out.println(a1[i][0]);
		}
		*/
		try{
			if (a1Reader != null){
				a1Reader.close();
			}
			if (a2Reader != null){
				a2Reader.close();
			}
			if (a3Reader != null){
				a3Reader.close();
			}
			if (a4Reader != null){
				a4Reader.close();
			}
			if (rewardsReader != null){
				rewardsReader.close();
			}
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
}