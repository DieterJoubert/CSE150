package cse150P7;

import java.text.DecimalFormat;

public class ValueIteration {
	
	public static double gamma = .98;
	
	public static void findValues(double[][]a1, double[][]a2, double[][]a3, 
							double[][]a4, int[]rewards){
		
		double[] values = new double[81];
		double[] newValues = new double[81];
		//init values to 0
		for (int i = 0; i < values.length; i++){
			values[i] = 0;
		}
		double sum1;
		double sum2;
		double sum3;
		double sum4;
		double max;
		int iterations = 0;
		//this better eventually break!
		while(true){
			//check all transitions
			for (int i = 0; i < 81; i++){
				sum1 = 0;
				sum2 = 0;
				sum3 = 0;
				sum4 = 0;
				for(int j = 0; j < 81; j++){
					sum1 += a1[i][j]*values[j];
					sum2 += a2[i][j]*values[j];
					sum3 += a3[i][j]*values[j];
					sum4 += a4[i][j]*values[j];
				}
				max = findMax(sum1,sum2,sum3,sum4);
				newValues[i] = rewards[i] + (gamma*max);
			}
			iterations++;
			if(checkConvergence(values,newValues)){
				values = copyArray(newValues);
				break;
			}
			values = copyArray(newValues);
		}
		DecimalFormat df = new DecimalFormat("#.##");
		System.out.println("This is the answer to CSE 150 HW 7 Section 4 Subsection a");
		System.out.println("Answer found in " + iterations + " iterations using an " +
				"equality range of +/- .1");
		String s;
		for (int i = 0; i < 9; i++){
			System.out.println();
			for(int j = 0; j < 9; j++){
				s = df.format(values[(j*9)+i]);
				if (s.length() == 1){
					if (j == 0){
						System.out.print("|");
					}
					System.out.print("   " + s + "   |");
				}
				else if(s.length() == 4){
					if (j == 0){
						System.out.print("|");
					}
					System.out.print(" " + s + "  |");
				}
				else{
					System.out.print(" " + s + " |");
				}
			}
			
		}
		FindOptimalPolicy(values);
		
	}
	
	public static void FindOptimalPolicy(double[] values){
		char[] pi = new char[81];
		double west,north,south,east, max;
		char maxChar;
		for (int i = 0; i < 81; i++){
			if(i >= 0 && i <= 8){
				west = 0;
			}
			else{
				west = values[i-9];
			}
			max = west;
			maxChar = 'W';
			if (i % 9 == 0){
				north = 0;
			}
			else{
				north = values[i-1]; 
			}
			if (north > max){
				max = north;
				maxChar = 'N';
			}
			if (i % 8 == 0){
				south = 0;
			}
			else{
				south = values[i+1];
			}
			if (south > max){
				max = south;
				maxChar = 'S';
			}
			if (i >= 72 && i <= 80){
				east = 0;
			}
			else{
				east = values[i+9];
			}		
			if(east > max){
				max = east;
				maxChar = 'E';
			}
			pi[i] = maxChar;
		}
		System.out.println();
		System.out.println();
		System.out.println("This is the solution to CSE 150 HW 7 Section 4 Subsection b");
		for (int i = 0; i < 9; i++){
			System.out.println();
			for(int j = 0; j < 9; j++){
				System.out.print(pi[(j*9)+i] + "   ");
			}
		}
	}
	
	public static double[] copyArray(double[] newValues){
		double[] copy = new double[81];
		for(int i = 0; i < 81; i++){
			copy[i] = newValues[i];
		}
		return copy;
	}
	
	public static boolean checkConvergence(double[] values, double[] newValues){
		boolean flag = true;
		for (int i = 0; i < 81; i++){
			if (newValues[i] < (values[i]-.1) || newValues[i] > (values[i]+.1)){
				flag = false;
			}
		}
		return flag;
	}
	
	public static double findMax(double a, double b, double c, double d){
		double currMax = a;
		if (b > currMax){
			currMax = b;
		}
		if(c > currMax){
			currMax = c;
		}
		if(d > currMax){
			currMax = d;
		}
		return currMax;
	}

}
