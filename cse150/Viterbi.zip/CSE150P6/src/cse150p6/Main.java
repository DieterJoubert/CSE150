package cse150p6;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;


/*
 * Elias Tong
 * CSE 150 / Saul
 * A06951741
 */

public class Main {
	
	public static void main (String args[]){
		System.out.println("Enter your emission matrix, transition matrix, initial state " +
				"distribution, and observations (in this order)");
		System.out.println(">>");
		BufferedReader emissionReader = null;
		BufferedReader transitionReader = null;
		BufferedReader InitialStateReader = null;
		BufferedReader ObservationReader = null;
		String a;
		StringTokenizer tokenizer;
		int row = -1;
		int col = -1;
		double[][] emission = new double[26][2];
		double[][] transition = new double[26][26];
		double[] initial = new double[26];
		int[] observation = new int[40000];
		try{
			emissionReader = new BufferedReader(new FileReader(args[0]));
			transitionReader = new BufferedReader(new FileReader(args[1]));
			InitialStateReader = new BufferedReader(new FileReader(args[2]));
			ObservationReader = new BufferedReader(new FileReader(args[3]));
				a = emissionReader.readLine();
				row++;
				while(a != null){
					tokenizer = new StringTokenizer(a);
					while(tokenizer.hasMoreTokens()){
						col++;
						emission [row][col] = Double.parseDouble(tokenizer.nextToken());
					}
					col = -1;
					a = emissionReader.readLine();
					row++;
				}
				row = -1;
				a = transitionReader.readLine();
				row++;
				while (a != null){
					tokenizer = new StringTokenizer(a);
					while(tokenizer.hasMoreTokens()){
						col++;
						transition [row][col] = Double.parseDouble(tokenizer.nextToken());
					}
					col = -1;
					a = transitionReader.readLine();
					row++;
				}
				row = -1;
				a = InitialStateReader.readLine();
				row++;
				while (a != null){
					tokenizer = new StringTokenizer(a);
					while(tokenizer.hasMoreTokens()){
						initial [row] = Double.parseDouble(tokenizer.nextToken());
					}
					a = InitialStateReader.readLine();
					row++;
				}
				row = -1;
				a = ObservationReader.readLine();
				while (a != null){
					tokenizer = new StringTokenizer(a);
					while(tokenizer.hasMoreTokens()){
						col++;
						observation [col] = Integer.parseInt(tokenizer.nextToken());
					}
					col = -1;
					a = ObservationReader.readLine();
				}
		}
		catch (FileNotFoundException e){
			System.err.println("Error: File not Found!!");
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}
		catch (Exception e){		
			e.printStackTrace();
		}
		finally{
			try{
				if (emissionReader != null){
					emissionReader.close();
				}
				if (transitionReader != null){
					transitionReader.close();
				}
				if(InitialStateReader != null){
					InitialStateReader.close();
				}
				if(ObservationReader != null){
					ObservationReader.close();
				}
			}
			catch(IOException e){
				e.printStackTrace();
			}
		}

		Viterbi2.performViterbi(emission, transition, initial, observation);

		try{
			if (emissionReader != null){
				emissionReader.close();
			}
			if (transitionReader != null){
				transitionReader.close();
			}
			if(InitialStateReader != null){
				InitialStateReader.close();
			}
			if(ObservationReader != null){
				ObservationReader.close();
			}
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
}