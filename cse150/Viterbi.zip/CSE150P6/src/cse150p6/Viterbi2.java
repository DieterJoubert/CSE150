package cse150p6;

import java.lang.Math;

public class Viterbi2 {
	
	public static void performViterbi(double[][] emission, double[][] transition, 
			double[] initial, int[] observations){
		
		double[][] LTable = new double [26][40000];
		
		//fill in first column
		for(int i = 0; i < 26; i++){
			LTable[i][0] = Math.log(initial[i]) + Math.log(emission[i][observations[0]]); 
			System.out.println(LTable[i][0]);
		}
		double currMax = 0;
		double temp;
		//fill in ALL columns (except first)
		//current column
		for (int t = 1; t < 40000; t++){
			//current node
			for (int j = 0; j < 26; j++){
				//previous node
				for(int i = 0; i < 26; i++){
					if (i == 0){
						currMax = LTable[i][t-1] + Math.log(transition[i][j]);
					}
					else{
						temp = LTable[i][t-1] + Math.log(transition[i][j]);
						if (temp > currMax){
							currMax = temp;
						}
					}
				}
				LTable[j][t] = currMax + Math.log(emission[j][observations[t]]);
			}
		}
		
		
	}

}
