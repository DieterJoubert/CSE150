// TODO - change "TeamName" to a name of your choice. Change the name of the
// folder containing this file as well.
package TeamName;

import CheckersPlayer.Solver;
import Checkers.Board;
import Checkers.Game;

// CustomSolver implementation goes here. You may create other classes
// and files as well, but make sure the are part of the (renamed) "TeamName" package

public class CustomSolver implements Solver {
  public int selectMove(Board b) {
    // TODO
    return 0;
  }
}
