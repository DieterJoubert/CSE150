package cse150;

import java.util.Vector;
import java.lang.Math;

public class EMUpdate {

	public static double productOfSequence(Vector<Double> p,Vector<Vector<Double>> x, int t){
		double d = 1.0;
		Vector<Double> row = x.get(t);
		for (int i = 0; i < 16; i++){
			d = d * Math.pow((1-p.get(i).doubleValue()),row.get(i));
		}
		return 1.0-d;
	}
	
	public static double Quotient (Vector<Double> y, Vector<Vector<Double>> x, 
									int i, Vector<Double> p, double denom, int t){
		double y_t = y.get(t).doubleValue();
		Vector<Double> row = x.get(t);
		double x_i_t = row.get(i).doubleValue();
		
		return ((y_t*x_i_t*p.get(i).doubleValue())/denom);
	}
	
	public static double Summation(Vector<Double> y, Vector<Vector<Double>> x, 
									Vector<Double> p, int i, int[] T_i){
		double ans = 0.0;
		double prod;
		double quotient;
		for (int t = 0; t < 8000; t++){
			prod = productOfSequence(p,x,t);
			quotient = Quotient(y,x,i,p,prod,t);
			ans += quotient;
		}
		return ans/(double) T_i[i];
	}
}
