package cse150;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;
import java.util.StringTokenizer;

public class Main {
	public static void main (String args[]){
		System.out.println("Enter your X data file followed by your Y data file");
		System.out.println(">>");
		Vector<Vector<Double>> XVector = new Vector<Vector<Double>>();
		Vector<Double> XInputs;
		Vector<Double> YVector = new Vector<Double>();
		BufferedReader x = null;
		BufferedReader y = null;
		String a;
		StringTokenizer b;
		int T_i[] = new int[16];
		int count;
		for (int inc = 0; inc < 16; inc++){
			T_i[inc] = 0;
		}
		try{
			x = new BufferedReader(new FileReader(args[0]));
			y = new BufferedReader(new FileReader(args[1]));
			a = x.readLine();
			while(a != null){
				b = new StringTokenizer(a);
				XInputs = new Vector<Double>();
				count = 0;
				while (b.hasMoreElements()){
					if (b.nextToken().equals("1.0000000e+00")){
						XInputs.addElement(new Double(1));
						T_i[count] = T_i[count] + 1;
					}
					else{
						XInputs.addElement(new Double(0));
					}	
					count++;
				}
				XVector.add(XInputs);
				a = x.readLine();
			}
			a = y.readLine();
			while (a != null){
				if (a.trim().equals("1.0000000e+00")){
					YVector.addElement(new Double (1));
				}
				else{
					YVector.addElement(new Double (0));
				}
				a = y.readLine();
			}
		}
		catch (FileNotFoundException e){
			System.err.println("Error: File not Found!!");
			e.printStackTrace();
		}
		catch (IOException e){
			e.printStackTrace();
		}
		catch (Exception e){		
			e.printStackTrace();
		}
		finally{
			try{
				if (x != null){
					x.close();
				}
				if (y != null){
					y.close();
				}
			}
			catch(IOException e){
				e.printStackTrace();
			}
		}
		
		double answer;
		LogLikelihood l = new LogLikelihood();
		System.out.println("This is the solution to CSE150 HW 5, Part 2");
		for (int q = 0; q <= 64; q++){
			answer = l.Summation(YVector,XVector,T_i);
			if (q == 0 || q == 1 || q == 2 || q == 4 || q == 8 || q == 16 || q == 32 || q == 64){
				System.out.println("On iteration " + q + " the log likelihood is " + answer);
			}
		}	
		
		try{
			if (x != null){
				x.close();
			}
			if (y != null){
				y.close();
			}
		}
		catch(IOException e){
			e.printStackTrace();
		}

	}

}

