package cse150;

import java.util.Enumeration;
import java.util.Vector;
import java.lang.Math;

public class LogLikelihood {
	
	public Vector<Double> params;
	public int iteration = 0;
	
	public LogLikelihood(){
		params = new Vector<Double>();	
		for (int i = 0; i < 16; i++){
			params.addElement(new Double(.25));
		}
	}
	
	public void performUpdate(Vector<Double> y, Vector<Vector<Double>> x, int[] T_i){
		Vector<Double> updatedParams = new Vector<Double>();
		for (int i = 0; i < 16; i++){
			updatedParams.addElement(new Double(EMUpdate.Summation(y,x,params,i,T_i)));
		}
		params = updatedParams;
		//checkParams();
	}
	
	public double findProbability(Vector<Double> y, Vector<Vector<Double>> x, int t, int[] T_i){
		double x_i;
		double power;
		double ans = 1.0;
		for (int i = 0; i < 16; i++){
			x_i = (x.get(t)).get(i).doubleValue();
			power = Math.pow(1.0-params.get(i).doubleValue(),x_i);
			ans *= power;
		}
		if (Math.round(y.get(t).doubleValue()) == 1){
			return 1.0-ans;
		}
		else{
			return ans;
		}
	}
	
	public double Summation(Vector<Double> y, Vector<Vector<Double>> x, int[] T_i){
		double ans = 0.0;
		if (iteration > 0){
			performUpdate(y,x, T_i);
		}
		iteration ++;
		for (int t = 0; t < 8000; t++){
			ans += Math.log(findProbability(y,x,t, T_i));
		}
		return ans/8000.00;
	}
	
	public void checkParams(){
		Enumeration<Double> e = params.elements();
		System.out.println("These are the params for iteration " + iteration);
		while(e.hasMoreElements()){
			System.out.println(e.nextElement());
		}
	}
}
